# candle > 2022-04-12 3:33pm
https://universe.roboflow.com/lee-escpi/candle-8bocu

Provided by a Roboflow user
License: CC BY 4.0

