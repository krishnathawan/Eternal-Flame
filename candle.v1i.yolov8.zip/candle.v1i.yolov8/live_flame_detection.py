import cv2
from ultralytics import YOLO

# Load the trained YOLOv8 model
model = YOLO('trained_flame_detection_model.pt')

# Open a webcam stream (0 indicates the default camera, change it if needed)
cap = cv2.VideoCapture(0)

while True:
    # Read a frame from the webcam
    ret, frame = cap.read()
    if not ret:
        break
    
    # Perform detection on the frame
    results = model.predict(source=frame, conf=0.5, show=True)

    # Check if any detections were made
    if len(results[0].boxes) > 0:
        print("Flame detected!")
    else:
        print("No flame detected.")
    
    # Display the results on the screen
    cv2.imshow('Live Flame Detection', frame)
    
    # Break the loop if 'q' is pressed
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

# Release the webcam and close all windows
cap.release()
cv2.destroyAllWindows()
